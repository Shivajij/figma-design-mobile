import "./SaturdayContainer.css";
import PropTypes from 'prop-types';

const SaturdayContainer = ({ className = "" }) => {
  return (
    <div className={`saturday-container ${className}`}>
      <div className="saturday-row">
        <div className="saturday-row-child" />
        <b className="saturday2">Saturday</b>
        <div className="april-label-saturday">
          <div className="apr-81">Apr 8</div>
        </div>
      </div>
      <img className="vector-icon6" loading="lazy" alt="" src="/vector-1.svg" />
      <img
        className="osfp-mak-s-2-icon1"
        loading="lazy"
        alt=""
        src="/osfpmaks-2@2x.png"
      />
    </div>
  );
};

SaturdayContainer.propTypes = {
  className: PropTypes.string,
};

export default SaturdayContainer;
