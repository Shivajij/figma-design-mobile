import "./BonusAvaliable.css";
import PropTypes from 'prop-types';

const BonusAvaliable = ({ className = "" }) => {
  return (
    <div className={`bonus-avaliable ${className}`}>
      <div className="bonus-available">Bonus Available</div>
      <div className="bonus-available1">Bonus Available</div>
      <div className="bonus-available2">Bonus Available</div>
      <div className="bonus-available3">Bonus Available</div>
      <img className="icon-2" alt="" src="/icon-2@2x.png" />
      <img className="icon-3" alt="" src="/icon-2@2x.png" />
      <img className="icon-4" alt="" src="/icon-2@2x.png" />
      <img className="icon-8" alt="" src="/icon-2@2x.png" />
    </div>
  );
};

BonusAvaliable.propTypes = {
  className: PropTypes.string,
};

export default BonusAvaliable;
