import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import "./DateNavigation1.css";

const DateNavigation1 = ({ className = "" }) => {
  const navigate = useNavigate();

  const onXIconClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onFlagsContainerClick = useCallback(() => {
    navigate("/start-page-phone-menu");
  }, [navigate]);

  return (
    <div className={`date-navigation1 ${className}`}>
      <div className="tomorrow8">
        <div className="day-containers" />
        <b className="tomorrow9">Tomorrow</b>
        <div className="month-containers">
          <div className="apr-14">Apr 1</div>
        </div>
      </div>
      <div className="day-selectors">
        <div className="day-selectors-child" />
        <b className="friday5">Friday</b>
        <div className="apr-7-frame">
          <div className="apr-74">Apr 7</div>
        </div>
      </div>
      <img className="bay-laz-s-2-icon4" alt="" src="/baylazs-2@2x.png" />
      <img className="timebattery-icon4" alt="" src="/timebattery2.svg" />
      <div className="date-navigation-child" />
      <img className="vector-icon31" loading="lazy" alt="" src="/vector.svg" />
      <div className="footer-content">
        <div className="footer-content-child" />
        <div className="menu-options">
          <div className="responsible-gaming-menu">
            <img
              className="x-icon2"
              loading="lazy"
              alt=""
              src="/x.svg"
              onClick={onXIconClick}
            />
          </div>
          <div className="about-us-menu">
            <div className="about-us-item">
              <img
                className="responsible-gambling-12"
                loading="lazy"
                alt=""
                src="/responsible-gambling-1@2x.png"
              />
              <div className="about-us-frame">
                <a className="about-us1">About us</a>
              </div>
            </div>
            <div className="gaming-menu">
              <div className="gaming-item">
                <div className="gaming-link">
                  <img
                    className="responsible-gambling-13"
                    loading="lazy"
                    alt=""
                    src="/responsible-gambling-1-1.svg"
                  />
                </div>
                <a className="responsible-gaming1">
                  <p className="responsible1">{`Responsible `}</p>
                  <p className="gaming1">Gaming</p>
                </a>
              </div>
            </div>
            <div className="help-menu">
              <div className="help-item">
                <img
                  className="help-1-icon1"
                  loading="lazy"
                  alt=""
                  src="/help-1.svg"
                />
                <div className="help-wrapper">
                  <h1 className="help1">Help</h1>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="language-menu">
          <div className="swedish-option">
            <div className="swedish-container">
              <img className="image-21-icon3" alt="" src="/image-21@2x.png" />
            </div>
            <h3 className="swedish">Swedish</h3>
          </div>
        </div>
        <div className="greek-option">
          <div className="greek-container">
            <div className="greek-item">
              <div className="greek-flag-container">
                <img
                  className="image-21-icon4"
                  alt=""
                  src="/image-21-11@2x.png"
                />
              </div>
              <h3 className="greek">Greek</h3>
            </div>
            <div className="other-languages">
              <div className="spanish-portuguese">
                <div className="flag-labels">
                  <img
                    className="image-21-icon5"
                    alt=""
                    src="/image-21-2@2x.png"
                  />
                </div>
                <h3 className="spanish">Spanish</h3>
              </div>
              <div className="spanish-portuguese1">
                <div className="image-21-frame">
                  <img
                    className="image-21-icon6"
                    alt=""
                    src="/image-21-3@2x.png"
                  />
                </div>
                <h3 className="portugese">Portugese</h3>
              </div>
              <div className="flags1" onClick={onFlagsContainerClick}>
                <div className="english-flag-container">
                  <img
                    className="image-21-icon7"
                    loading="lazy"
                    alt=""
                    src="/image-211@2x.png"
                  />
                </div>
                <h3 className="english1">English</h3>
                <div className="vector-wrapper5">
                  <img className="vector-icon32" alt="" src="/vector-91.svg" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

DateNavigation1.propTypes = {
  className: PropTypes.string,
};

export default DateNavigation1;
