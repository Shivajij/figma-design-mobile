import "./LiveGames3.css";
import PropTypes from 'prop-types';

const LiveGames3 = ({ className = "" }) => {
  return (
    <div className={`live-games12 ${className}`}>
      <div className="philadelphia10">
        <img className="nba-icon15" loading="lazy" alt="" src="/nba-3.svg" />
        <img className="nba-icon16" loading="lazy" alt="" src="/nba.svg" />
        <div className="philadelphia-76ers9">
          <p className="philadelphia11">{`Philadelphia `}</p>
          <p className="ers9">76ers</p>
        </div>
        <div className="boston-celtic22">Boston Celtic</div>
        <b className="live-space">0 - 1</b>
        <img className="vector-icon36" alt="" src="/vector-5.svg" />
        <div className="live40" />
      </div>
      <div className="boston-generals4">
        <img
          className="image-29-icon24"
          loading="lazy"
          alt=""
          src="/image-29-5@2x.png"
        />
        <img
          className="image-28-icon25"
          loading="lazy"
          alt=""
          src="/image-28-1@2x.png"
        />
        <div className="boston-generals5">Boston Generals</div>
        <div className="boston-celtic23">Boston Celtic</div>
        <div className="generals-live">
          <b className="b28">0 - 1</b>
          <img
            className="ciltv-icon12"
            loading="lazy"
            alt=""
            src="/ciltv.svg"
          />
          <b className="h19">45’ 1 H</b>
        </div>
        <div className="live41" />
        <img className="vector-icon37" alt="" src="/vector.svg" />
      </div>
      <b className="ncaa-basketball5">19:30 NCAA Basketball</b>
    </div>
  );
};

LiveGames3.propTypes = {
  className: PropTypes.string,
};

export default LiveGames3;
