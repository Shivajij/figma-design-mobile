import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import StartPagePhone from "./pages/StartPagePhone";
import StartPagePhoneFilter from "./pages/StartPagePhoneFilter";
import StartPagePhoneMenu from "./pages/StartPagePhoneMenu";
import StartPagePhoneMenuLangueag from "./pages/StartPagePhoneMenuLangueag";
import NCAABasketballMatchGameS from "./pages/NCAABasketballMatchGameS";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/start-page-phone-filter":
        title = "";
        metaDescription = "";
        break;
      case "/start-page-phone-menu":
        title = "";
        metaDescription = "";
        break;
      case "/start-page-phone-menu-langueage":
        title = "";
        metaDescription = "";
        break;
      case "/ncaa-basketball-match-game-statistics":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<StartPagePhone />} />
      <Route
        path="/start-page-phone-filter"
        element={<StartPagePhoneFilter />}
      />
      <Route path="/start-page-phone-menu" element={<StartPagePhoneMenu />} />
      <Route
        path="/start-page-phone-menu-langueage"
        element={<StartPagePhoneMenuLangueag />}
      />
      <Route
        path="/ncaa-basketball-match-game-statistics"
        element={<NCAABasketballMatchGameS />}
      />
    </Routes>
  );
}
export default App;
