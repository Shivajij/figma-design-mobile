import LiveGames2 from "../components/LiveGames2";
import DateNavigation from "../components/DateNavigation";
import BottomContainer from "../components/BottomContainer";
import "./StartPagePhoneMenu.css";

const StartPagePhoneMenu = () => {
  return (
    <div className="start-page-phone-menu">
      <div className="thursday2">
        <div className="thursday-item" />
        <div className="apr-21">Apr 2</div>
        <b className="thursday3">Thursday</b>
      </div>
      <main className="frame-parent">
        <div className="header-wrapper">
          <img
            className="header-icon2"
            loading="lazy"
            alt=""
            src="/header@2x.png"
          />
        </div>
        <img
          className="osfp-mak-s-1-icon1"
          loading="lazy"
          alt=""
          src="/osfpmaks-1@2x.png"
        />
        <div className="today2">
          <div className="date-background" />
          <div className="today-wrapper">
            <b className="today3">Today</b>
          </div>
          <div className="mar-301">Mar 30</div>
        </div>
        <h3 className="live-games1">Live Games</h3>
        <div className="live1" />
        <section className="live-games-wrapper">
          <LiveGames2 />
        </section>
        <DateNavigation />
      </main>
      <div className="top-divider" />
      <div className="start-page-phone-menu-child" />
      <div className="start-page-phone-menu-item" />
      <div className="filter-by-sports2">Filter by sports or area</div>
      <div className="scroller2">
        <div className="scroller-child1" />
        <div className="scroller-child2" />
      </div>
      <BottomContainer
        propWidth="361.2px"
        propMinWidth="unset"
        propAlignSelf="unset"
        propWidth1="245.6px"
        propPadding="0px 20px 0px 0px"
        dateValuesDebugCommit="unset"
        dateIconDebugCommit="unset"
      />
      <div className="league-scroller">
        <div className="scroller3">
          <div className="scroller-child3" />
          <div className="scroll-container" />
        </div>
      </div>
    </div>
  );
};

export default StartPagePhoneMenu;
