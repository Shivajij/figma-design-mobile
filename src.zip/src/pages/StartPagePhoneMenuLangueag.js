import LiveGamesWrapper from "../components/LiveGamesWrapper";
import DateNavigation1 from "../components/DateNavigation1";
import BottomContainer from "../components/BottomContainer";
import "./StartPagePhoneMenuLangueag.css";

const StartPagePhoneMenuLangueag = () => {
  return (
    <div className="start-page-phone-menu-langueag">
      <div className="thursday4">
        <div className="thursday-inner" />
        <div className="apr-22">Apr 2</div>
        <b className="thursday5">Thursday</b>
      </div>
      <main className="frame-group">
        <div className="header-frame">
          <img
            className="header-icon3"
            loading="lazy"
            alt=""
            src="/header@2x.png"
          />
        </div>
        <img
          className="osfp-mak-s-1-icon2"
          loading="lazy"
          alt=""
          src="/osfpmaks-1@2x.png"
        />
        <div className="today4">
          <div className="today-child" />
          <div className="today-container">
            <b className="today5">Today</b>
          </div>
          <div className="mar-302">Mar 30</div>
        </div>
        <h3 className="live-games2">Live Games</h3>
        <div className="live2" />
        <LiveGamesWrapper />
        <DateNavigation1 />
      </main>
      <div className="start-page-phone-menu-langueag-child" />
      <div className="start-page-phone-menu-langueag-item" />
      <div className="start-page-phone-menu-langueag-inner" />
      <div className="filter-by-sports3">Filter by sports or area</div>
      <BottomContainer
        propWidth="225.6px"
        propMinWidth="225.5999999999999px"
        propAlignSelf="stretch"
        propWidth1="unset"
        propPadding="unset"
        dateValuesDebugCommit="unset"
        dateIconDebugCommit="unset"
      />
    </div>
  );
};

export default StartPagePhoneMenuLangueag;
