import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import "./FirstRow.css";

const FirstRow = ({ className = "" }) => {
  const navigate = useNavigate();

  const onFilterBySportsClick = useCallback(() => {
    navigate("/start-page-phone-filter");
  }, [navigate]);

  return (
    <div className={`first-row ${className}`}>
      <div className="live-scores">
        <img
          className="osfp-mak-s-1-icon4"
          loading="lazy"
          alt=""
          src="/osfpmaks-1@2x.png"
        />
        <img
          className="bay-laz-s-2-icon2"
          loading="lazy"
          alt=""
          src="/baylazs-2@2x.png"
        />
      </div>
      <div className="game-list">
        <div className="game-day">
          <div className="single-day">
            <div className="today9">
              <div className="today-inner" />
              <div className="today-label">
                <b className="today10">Today</b>
              </div>
              <div className="mar-304">Mar 30</div>
            </div>
            <div className="live-games-row">
              <h3 className="live-games5">Live Games</h3>
              <div className="live-indicator">
                <div className="live4" />
              </div>
            </div>
          </div>
          <div className="tomorrow4">
            <div className="tomorrow-inner" />
            <b className="tomorrow5">Tomorrow</b>
            <div className="april-label-tomorrow">
              <div className="apr-12">Apr 1</div>
            </div>
          </div>
          <div className="upcoming-games">
            <div className="days-of-week">
              <div className="thursday8">
                <div className="day-markers" />
                <b className="thursday9">Thursday</b>
                <div className="april-week">
                  <div className="apr-24">Apr 2</div>
                </div>
              </div>
              <div className="thursday-row">
                <div className="thursday-row-child" />
                <b className="friday3">Friday</b>
                <div className="apr-7-wrapper">
                  <div className="apr-72">Apr 7</div>
                </div>
              </div>
            </div>
            <div className="filter-row">
              <div className="filter-container">
                <div
                  className="filter-by-sports5"
                  onClick={onFilterBySportsClick}
                >
                  Filter by sports or area
                </div>
                <div className="filter-icon">
                  <img
                    className="vector-icon5"
                    loading="lazy"
                    alt=""
                    src="/vector.svg"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

FirstRow.propTypes = {
  className: PropTypes.string,
};

export default FirstRow;
