import "./LiveGames4.css";
import PropTypes from 'prop-types';

const LiveGames4 = ({ className = "" }) => {
  return (
    <div className={`live-games11 ${className}`}>
      <div className="header10">
        <div className="header11" />
        <b className="north-american-basketball4">
          20:00 North American Basketball League
        </b>
        <img
          className="basketball-2-icon8"
          loading="lazy"
          alt=""
          src="/basketball-21.svg"
        />
      </div>
      <div className="pittsburgh-steelmen8">
        <img
          className="image-29-icon23"
          loading="lazy"
          alt=""
          src="/image-29@2x.png"
        />
        <img
          className="image-28-icon24"
          loading="lazy"
          alt=""
          src="/image-28@2x.png"
        />
        <div className="pittsburgh-steelmen9">
          <p className="pittsburgh4">Pittsburgh</p>
          <p className="steelmen4">Steelmen</p>
        </div>
        <div className="boston-celtic20">Boston Celtic</div>
        <div className="live-marker">
          <b className="live-indicator2">0 - 2</b>
          <b className="h16">45’ 1 H</b>
        </div>
        <div className="live37" />
        <img
          className="vector-icon33"
          loading="lazy"
          alt=""
          src="/vector-4.svg"
        />
      </div>
      <div className="hornets-game1">
        <img className="nba-icon12" loading="lazy" alt="" src="/nba-2.svg" />
        <img className="nba-icon13" loading="lazy" alt="" src="/nba.svg" />
        <div className="philadelphia-76ers8">
          <p className="philadelphia9">{`Philadelphia `}</p>
          <p className="ers8">76ers</p>
        </div>
        <div className="charlotte-hornets4">
          <p className="charlotte4">Charlotte</p>
          <p className="hornets4">Hornets</p>
        </div>
        <img
          className="vector-icon34"
          loading="lazy"
          alt=""
          src="/vector-3.svg"
        />
        <div className="hornets-live">
          <b className="b26">0 - 1</b>
          <b className="h17">45’ 1 H</b>
        </div>
        <div className="live38" />
      </div>
      <div className="celtic-game">
        <img className="nba-icon14" loading="lazy" alt="" src="/nba-1.svg" />
        <img className="nfl-icon4" loading="lazy" alt="" src="/nfl.svg" />
        <div className="live39" />
        <div className="townsom4">Townsom</div>
        <div className="boston-celtic21">Boston Celtic</div>
        <div className="celtic-live">
          <b className="b27">0 - 1</b>
          <img
            className="ciltv-icon11"
            loading="lazy"
            alt=""
            src="/ciltv.svg"
          />
          <b className="h18">45’ 1 H</b>
        </div>
        <img className="vector-icon35" alt="" src="/vector-31.svg" />
      </div>
      <img
        className="basketball-2-icon9"
        loading="lazy"
        alt=""
        src="/basketball-21.svg"
      />
    </div>
  );
};

LiveGames4.propTypes = {
  className: PropTypes.string,
};

export default LiveGames4;
