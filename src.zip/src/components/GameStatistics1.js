import "./GameStatistics1.css";
import PropTypes from 'prop-types';

const GameStatistics1 = ({ className = "" }) => {
  return (
    <div className={`game-statistics ${className}`}>
      <div className="team-details-columns" />
      <div className="header12" />
      <div className="stats-categories">
        <div className="shots">Shots</div>
        <div className="shots-on-target">Shots on target</div>
        <div className="possession">Possession</div>
        <div className="passes">Passes</div>
        <div className="pass-accuracy">Pass accuracy</div>
        <div className="fouls">Fouls</div>
        <div className="yellow-cards">Yellow cards</div>
        <div className="red-cards">Red cards</div>
        <div className="offsides">Offsides</div>
        <div className="corners">Corners</div>
      </div>
      <div className="team-1-details">
        <div className="div9">28</div>
        <div className="div10">11</div>
        <div className="div11">41%</div>
        <div className="div12">509</div>
        <div className="div13">75%</div>
        <div className="div14">11</div>
        <div className="div15">1</div>
        <div className="div16">1</div>
        <div className="div17">3</div>
        <div className="div18">5</div>
      </div>
      <div className="team-2-details">
        <div className="div19">28</div>
        <div className="div20">11</div>
        <div className="div21">41%</div>
        <div className="div22">509</div>
        <div className="div23">75%</div>
        <div className="div24">11</div>
        <div className="div25">1</div>
        <div className="div26">1</div>
        <div className="div27">3</div>
        <div className="div28">5</div>
      </div>
      <div className="team-stats">Team Stats</div>
      <img className="nfl-icon5" loading="lazy" alt="" src="/nfl-1.svg" />
      <img className="nba-icon17" loading="lazy" alt="" src="/nba-5.svg" />
    </div>
  );
};

GameStatistics1.propTypes = {
  className: PropTypes.string,
};

export default GameStatistics1;
