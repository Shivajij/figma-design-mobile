import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import "./LiveGames2.css";

const LiveGames2 = ({ className = "" }) => {
  const navigate = useNavigate();

  const onLiveGamesContainerClick = useCallback(() => {
    navigate("/ncaa-basketball-match-game-statistics");
  }, [navigate]);

  return (
    <div
      className={`live-games9 ${className}`}
      onClick={onLiveGamesContainerClick}
    >
      <div className="live-games-inner" />
      <div className="game-info2">
        <div className="league-container">
          <div className="basketball-league2">
            <div className="header6" />
            <div className="basketball-icon1">
              <img
                className="basketball-2-icon4"
                loading="lazy"
                alt=""
                src="/basketball-2.svg"
              />
            </div>
            <b className="ncaa-basketball3">19:30 NCAA Basketball</b>
          </div>
          <div className="live-game-list">
            <div className="game-item">
              <div className="game-details1">
                <div className="team-container2">
                  <div className="away-team1">
                    <div className="away-team-info">
                      <div className="away-live">
                        <div className="live21" />
                      </div>
                      <img
                        className="nfl-icon2"
                        loading="lazy"
                        alt=""
                        src="/nfl.svg"
                      />
                    </div>
                  </div>
                  <div className="home-team1">
                    <div className="home-live">
                      <div className="live22" />
                    </div>
                    <img
                      className="nba-icon6"
                      loading="lazy"
                      alt=""
                      src="/nba.svg"
                    />
                  </div>
                </div>
              </div>
              <div className="second-game1">
                <div className="second-game-details">
                  <div className="team-info">
                    <div className="townsom2">Townsom</div>
                  </div>
                  <div className="home-team-details">
                    <div className="channel-logo">
                      <img
                        className="ciltv-icon7"
                        loading="lazy"
                        alt=""
                        src="/ciltv.svg"
                      />
                    </div>
                    <div className="channel-name">
                      <b className="channel-initial">0 - 1</b>
                    </div>
                    <div className="channel-word">
                      <b className="h8">45’ 1 H</b>
                    </div>
                  </div>
                  <div className="home-team-name1">
                    <div className="home-team-label">
                      <div className="home-team-city">
                        <div className="boston-celtic10">Boston Celtic</div>
                      </div>
                      <div className="home-team-instance">
                        <img
                          className="nba-icon7"
                          loading="lazy"
                          alt=""
                          src="/nba-1.svg"
                        />
                        <div className="vector-wrapper1">
                          <img
                            className="vector-icon16"
                            loading="lazy"
                            alt=""
                            src="/vector-2.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="third-game">
                  <div className="third-game-details">
                    <div className="team-label">
                      <div className="philadelphia-76ers4">
                        <p className="philadelphia5">{`Philadelphia `}</p>
                        <p className="ers4">76ers</p>
                      </div>
                    </div>
                    <div className="away-details">
                      <div className="away-name">
                        <b className="away-initial">0 - 1</b>
                        <div className="away-word">
                          <b className="h9">45’ 1 H</b>
                        </div>
                      </div>
                    </div>
                    <div className="home-info">
                      <div className="home-label1">
                        <div className="charlotte-hornets2">
                          <p className="charlotte2">Charlotte</p>
                          <p className="hornets2">Hornets</p>
                        </div>
                      </div>
                      <img
                        className="nba-icon8"
                        loading="lazy"
                        alt=""
                        src="/nba-2.svg"
                      />
                      <div className="home-team-details-container">
                        <img
                          className="vector-icon17"
                          loading="lazy"
                          alt=""
                          src="/vector-3.svg"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="fourth-game">
          <div className="fourth-game-details">
            <div className="team-and-score">
              <div className="score-container">
                <img
                  className="image-28-icon12"
                  loading="lazy"
                  alt=""
                  src="/image-28@2x.png"
                />
                <div className="live23" />
              </div>
              <div className="team-name-container1">
                <div className="pittsburgh-steelmen4">
                  <p className="pittsburgh2">Pittsburgh</p>
                  <p className="steelmen2">Steelmen</p>
                </div>
              </div>
            </div>
            <div className="away-team-city-container">
              <div className="away-city-name">
                <b className="away-city-initial">0 - 2</b>
                <div className="away-city-word">
                  <b className="h10">45’ 1 H</b>
                </div>
              </div>
            </div>
            <div className="home-team-info">
              <div className="home-team-name-container">
                <div className="home-city-label">
                  <div className="boston-celtic11">Boston Celtic</div>
                </div>
                <div className="home-team-logo-container">
                  <img
                    className="image-29-icon11"
                    loading="lazy"
                    alt=""
                    src="/image-29@2x.png"
                  />
                  <img className="vector-icon18" alt="" src="/vector-4.svg" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="header-parent">
          <div className="header7" />
          <div className="league-info1">
            <img
              className="basketball-2-icon5"
              alt=""
              src="/basketball-2.svg"
            />
          </div>
          <b className="north-american-basketball2">
            20:00 North American Basketball League
          </b>
        </div>
      </div>
      <div className="image-gallery">
        <div className="gallery-container">
          <div className="first-image">
            <img
              className="image-29-icon12"
              loading="lazy"
              alt=""
              src="/image-29-1@2x.png"
            />
            <img className="vector-icon19" alt="" src="/vector-5.svg" />
          </div>
          <div className="image-pair">
            <img
              className="image-29-icon13"
              loading="lazy"
              alt=""
              src="/image-29-2@2x.png"
            />
            <img className="vector-icon20" alt="" src="/vector-5.svg" />
          </div>
          <div className="second-image">
            <img
              className="image-29-icon14"
              loading="lazy"
              alt=""
              src="/image-29-3@2x.png"
            />
            <img className="vector-icon21" alt="" src="/vector-5.svg" />
          </div>
          <div className="image-pair1">
            <img
              className="image-29-icon15"
              loading="lazy"
              alt=""
              src="/image-29-4@2x.png"
            />
            <img
              className="vector-icon22"
              loading="lazy"
              alt=""
              src="/vector-5.svg"
            />
          </div>
          <div className="live-game-list1">
            <div className="live-game-row1">
              <div className="game-details2">
                <div className="game-item1">
                  <div className="game-content">
                    <div className="live-indicator1">
                      <img
                        className="image-28-icon13"
                        loading="lazy"
                        alt=""
                        src="/image-28-1@2x.png"
                      />
                      <div className="live24" />
                    </div>
                  </div>
                  <div className="team-name-container2">
                    <div className="boston-generals2">Boston Generals</div>
                  </div>
                  <div className="game-network">
                    <div className="network-logo">
                      <img className="ciltv-icon8" alt="" src="/ciltv.svg" />
                    </div>
                    <div className="network-placeholder">
                      <b className="network-availability">0 - 1</b>
                    </div>
                    <div className="network-label">
                      <b className="h11">45’ 1 H</b>
                    </div>
                  </div>
                </div>
                <div className="home-team-name-container1">
                  <div className="boston-celtic12">Boston Celtic</div>
                </div>
              </div>
              <div className="game-info3">
                <div className="game-teams">
                  <div className="team-names1">
                    <div className="home-team2">
                      <img
                        className="image-28-icon14"
                        loading="lazy"
                        alt=""
                        src="/image-28-2@2x.png"
                      />
                      <div className="live25" />
                    </div>
                    <div className="home-team-name2">
                      <div className="denver-wolves2">Denver Wolves</div>
                    </div>
                  </div>
                  <div className="away-team-names">
                    <b className="away-team-city1">0 - 1</b>
                  </div>
                </div>
                <div className="team-cities">
                  <div className="mavericks2">Mavericks</div>
                </div>
              </div>
              <div className="game-info4">
                <div className="frame-parent2">
                  <div className="image-28-container">
                    <img
                      className="image-28-icon15"
                      loading="lazy"
                      alt=""
                      src="/image-28-3@2x.png"
                    />
                    <div className="live26" />
                  </div>
                  <div className="philadelphia-76ers-container">
                    <div className="philadelphia-76ers5">
                      <p className="philadelphia6">{`Philadelphia `}</p>
                      <p className="ers5">76ers</p>
                    </div>
                  </div>
                </div>
                <div className="game-info-inner">
                  <div className="placeholder-parent">
                    <b className="placeholder">0 - 1</b>
                    <div className="boston-celtic13">Boston Celtic</div>
                  </div>
                </div>
              </div>
              <div className="game-info5">
                <div className="frame-parent3">
                  <div className="image-28-parent1">
                    <img
                      className="image-28-icon16"
                      loading="lazy"
                      alt=""
                      src="/image-28-4@2x.png"
                    />
                    <div className="live27" />
                  </div>
                  <div className="newark-bears-container">
                    <div className="newark-bears2">Newark Bears</div>
                  </div>
                </div>
                <div className="game-info-child">
                  <div className="parent">
                    <b className="b19">0 - 1</b>
                    <div className="boston-celtic14">Boston Celtic</div>
                  </div>
                </div>
              </div>
              <div className="game-info6">
                <div className="frame-parent4">
                  <div className="image-28-parent2">
                    <img
                      className="image-28-icon17"
                      loading="lazy"
                      alt=""
                      src="/image-28-5@2x.png"
                    />
                    <div className="live28" />
                  </div>
                  <div className="pittsburgh-steelmen-wrapper">
                    <div className="pittsburgh-steelmen5">
                      Pittsburgh Steelmen
                    </div>
                  </div>
                  <div className="time-container">
                    <b className="game-time">0 - 1</b>
                  </div>
                </div>
                <div className="portland-lumberjacks-wrapper">
                  <div className="portland-lumberjacks2">
                    <p className="portland2">Portland</p>
                    <p className="lumberjacks2">Lumberjacks</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="away-team-indicator">
              <div className="away-team-logo">
                <img
                  className="image-29-icon16"
                  loading="lazy"
                  alt=""
                  src="/image-29-5@2x.png"
                />
                <img className="away-team-status" alt="" src="/vector.svg" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <img className="footer-icon3" alt="" src="/footer@2x.png" />
    </div>
  );
};

LiveGames2.propTypes = {
  className: PropTypes.string,
};

export default LiveGames2;
