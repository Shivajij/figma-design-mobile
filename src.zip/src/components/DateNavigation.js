import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import "./DateNavigation.css";

const DateNavigation = ({ className = "" }) => {
  const navigate = useNavigate();

  const onXIconClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onFlagsContainerClick = useCallback(() => {
    navigate("/start-page-phone-menu-langueage");
  }, [navigate]);

  return (
    <div className={`date-navigation ${className}`}>
      <div className="tomorrow6">
        <div className="day-highlight" />
        <b className="tomorrow7">Tomorrow</b>
        <div className="day-month">
          <div className="apr-13">Apr 1</div>
        </div>
      </div>
      <div className="day-selector">
        <div className="day-selector-child" />
        <b className="friday4">Friday</b>
        <div className="apr-7-container">
          <div className="apr-73">Apr 7</div>
        </div>
      </div>
      <img className="bay-laz-s-2-icon3" alt="" src="/baylazs-2@2x.png" />
      <img className="timebattery-icon3" alt="" src="/timebattery2.svg" />
      <div className="divider" />
      <img
        className="bottom-gradient-icon"
        loading="lazy"
        alt=""
        src="/vector.svg"
      />
      <div className="footer-links">
        <div className="footer-links-child" />
        <div className="menu-icon">
          <img
            className="x-icon1"
            loading="lazy"
            alt=""
            src="/x.svg"
            onClick={onXIconClick}
          />
        </div>
        <div className="about-us-link">
          <div className="about-us-container">
            <img
              className="responsible-gambling-1"
              loading="lazy"
              alt=""
              src="/responsible-gambling-1@2x.png"
            />
            <div className="about-us-wrapper">
              <a className="about-us">About us</a>
            </div>
          </div>
        </div>
        <div className="responsible-gaming-link">
          <div className="gaming-container">
            <div className="gaming-label">
              <img
                className="responsible-gambling-11"
                loading="lazy"
                alt=""
                src="/responsible-gambling-1-1.svg"
              />
            </div>
            <a className="responsible-gaming">
              <p className="responsible">{`Responsible `}</p>
              <p className="gaming">Gaming</p>
            </a>
          </div>
          <div className="help-link">
            <img
              className="help-1-icon"
              loading="lazy"
              alt=""
              src="/help-1.svg"
            />
            <div className="help-container">
              <h1 className="help">Help</h1>
            </div>
          </div>
        </div>
        <div className="language-selector">
          <div className="flags" onClick={onFlagsContainerClick}>
            <div className="flag-icon">
              <img
                className="image-21-icon2"
                loading="lazy"
                alt=""
                src="/image-211@2x.png"
              />
            </div>
            <a className="english">English</a>
            <div className="vector-wrapper2">
              <img className="vector-icon23" alt="" src="/vector-91.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

DateNavigation.propTypes = {
  className: PropTypes.string,
};

export default DateNavigation;
