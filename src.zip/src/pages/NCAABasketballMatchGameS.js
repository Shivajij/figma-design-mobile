import { useCallback } from "react";
import LiveGames4 from "../components/LiveGames4";
import LiveGames3 from "../components/LiveGames3";
import BonusAvaliable from "../components/BonusAvaliable";
import Odds from "../components/Odds";
import { useNavigate } from "react-router-dom";
import GameStatistics1 from "../components/GameStatistics1";
import GameStatistics from "../components/GameStatistics";
import "./NCAABasketballMatchGameS.css";

const NCAABasketballMatchGameS = () => {
  const navigate = useNavigate();

  const onFilterBySportsClick = useCallback(() => {
    navigate("/start-page-phone-filter");
  }, [navigate]);

  const onContentClick = useCallback(() => {
    // Please sync "NCAA Basketball Match - Match Events" to the project
  }, []);

  return (
    <div className="ncaa-basketball-match-game-s">
      <div className="today6">
        <div className="today7">
          <div className="today-item" />
          <b className="today8">Today</b>
          <div className="mar-303">Mar 30</div>
        </div>
        <div className="tomorrow2">
          <div className="tomorrow-item" />
          <div className="apr-11">Apr 1</div>
          <b className="tomorrow3">Tomorrow</b>
        </div>
        <div className="thursday6">
          <div className="thursday-child1" />
          <div className="apr-23">Apr 2</div>
          <b className="thursday7">Thursday</b>
        </div>
        <div className="friday1">
          <div className="friday-child" />
          <div className="apr-71">Apr 7</div>
          <b className="friday2">Friday</b>
        </div>
        <div className="saturday">
          <div className="saturday-child" />
          <div className="apr-8">Apr 8</div>
          <b className="saturday1">Saturday</b>
        </div>
        <img
          className="vector-icon2"
          loading="lazy"
          alt=""
          src="/vector-1.svg"
        />
      </div>
      <header className="promotions">
        <img
          className="osfp-mak-s-1-icon3"
          loading="lazy"
          alt=""
          src="/osfpmaks-1@2x.png"
        />
        <img
          className="osfp-mak-s-2-icon"
          loading="lazy"
          alt=""
          src="/osfpmaks-2@2x.png"
        />
        <img
          className="bay-laz-s-2-icon1"
          loading="lazy"
          alt=""
          src="/baylazs-2@2x.png"
        />
      </header>
      <img
        className="timebattery-icon2"
        loading="lazy"
        alt=""
        src="/timebattery1.svg"
      />
      <div className="ncaa-basketball-match-game-s-child" />
      <img
        className="header-icon4"
        loading="lazy"
        alt=""
        src="/header@2x.png"
      />
      <div className="rectangle-container">
        <div className="group-child" />
        <div className="group-item" />
        <div className="group-inner" />
      </div>
      <section className="sponsor-logos">
        <footer className="live-games3">
          <div className="header-elements" />
          <div className="header" />
          <div className="header1" />
          <LiveGames4 />
          <LiveGames3 />
          <div className="submarket">
            <b className="full-time-result">Full Time Result</b>
            <div className="vector-parent">
              <img className="rectangle-icon" alt="" src="/rectangle-73.svg" />
              <b className="double-chance">Double Chance</b>
            </div>
            <div className="vector-group">
              <img className="group-child1" alt="" src="/rectangle-73.svg" />
              <b className="half-time-result">Half Time Result</b>
            </div>
            <div className="vector-container">
              <img className="group-child2" alt="" src="/rectangle-75.svg" />
              <b className="both-teams-scores">Both Teams Scores</b>
            </div>
            <div className="group-div">
              <img className="group-child3" alt="" src="/rectangle-73.svg" />
              <b className="draw-no-bet">Draw No Bet</b>
            </div>
            <img className="mask-group-icon" alt="" src="/mask-group.svg" />
            <img className="vector-icon3" alt="" />
          </div>
          <BonusAvaliable />
        </footer>
        <div className="live3" />
        <div className="live-games4">Live Games</div>
        <div className="sponsor-elements">
          <div className="sponsor-elements-child" />
          <img
            className="sport-icon"
            loading="lazy"
            alt=""
            src="/888sport@2x.png"
          />
          <b className="sek-500">SEK 500</b>
        </div>
        <div className="sponsor-elements1">
          <img
            className="sponsor-elements-item"
            loading="lazy"
            alt=""
            src="/rectangle-39@2x.png"
          />
          <b className="sek-12">SEK 12</b>
        </div>
        <div className="sponsor-elements2">
          <img
            className="sponsor-elements-inner"
            loading="lazy"
            alt=""
            src="/rectangle-39-1@2x.png"
          />
          <b className="sek-5001">SEK 500</b>
        </div>
        <div className="unibet">
          <div className="unibet-child" />
          <img
            className="unibet-icon"
            loading="lazy"
            alt=""
            src="/unibet@2x.png"
          />
          <b className="sek-100">SEK 100</b>
        </div>
        <div className="betfair">
          <div className="betfair-child" />
          <img
            className="betfair-icon"
            loading="lazy"
            alt=""
            src="/betfair@2x.png"
          />
          <b className="sek-2022">SEK 20.22</b>
        </div>
        <div className="betsafe">
          <div className="betsafe-child" />
          <img
            className="betsafe-icon"
            loading="lazy"
            alt=""
            src="/betsafe@2x.png"
          />
          <b className="sek-5002">SEK 500</b>
        </div>
        <div className="odds4">
          <div className="ciltv-logos">
            <div className="upper-logos" />
            <b className="lower-logos">1,22</b>
          </div>
          <div className="ciltv-logos1">
            <div className="upper-names" />
            <b className="lower-names">2,60</b>
          </div>
          <div className="ciltv-logos2">
            <div className="upper-cltv" />
            <b className="lower-cltv">3,80</b>
          </div>
        </div>
        <div className="odds41">
          <div className="div">
            <div className="child" />
            <b className="b7">1,22</b>
          </div>
          <div className="div1">
            <div className="item" />
            <b className="b8">2,60</b>
          </div>
          <div className="div2">
            <div className="inner" />
            <b className="b9">3,80</b>
          </div>
        </div>
        <div className="odds3">
          <div className="div3">
            <div className="child1" />
            <b className="b10">1,22</b>
          </div>
          <div className="div4">
            <div className="child2" />
            <b className="b11">2,60</b>
          </div>
          <div className="div5">
            <div className="child3" />
            <b className="b12">3,50</b>
          </div>
        </div>
        <div className="odds2">
          <div className="div6">
            <div className="child4" />
            <b className="b13">1,19</b>
          </div>
          <div className="div7">
            <div className="child5" />
            <b className="b14">2,60</b>
          </div>
          <div className="div8">
            <div className="child6" />
            <b className="b15">3,80</b>
          </div>
        </div>
        <Odds />
        <div className="filter-by-sports4" onClick={onFilterBySportsClick}>
          Filter by sports or area
        </div>
        <img className="vector-icon4" alt="" src="/vector.svg" />
        <img className="ciltv-icon" alt="" src="/ciltv-2.svg" />
        <img className="ciltv-icon1" alt="" src="/ciltv-2.svg" />
        <img className="ciltv-icon2" alt="" src="/ciltv-2.svg" />
      </section>
      <section className="content" onClick={onContentClick}>
        <GameStatistics1 />
        <GameStatistics />
      </section>
      <img
        className="scroller-icon"
        loading="lazy"
        alt=""
        src="/scroller@2x.png"
      />
      <div className="scroller4">
        <div className="scroller-handles" />
        <div className="scroller-handles1" />
      </div>
      <img className="footer-icon2" alt="" src="/footer@2x.png" />
    </div>
  );
};

export default NCAABasketballMatchGameS;
