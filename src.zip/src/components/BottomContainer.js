import { useMemo } from "react";
import "./BottomContainer.css";
import PropTypes from 'prop-types';

const BottomContainer = ({
  className = "",
  propWidth,
  propMinWidth,
  propAlignSelf,
  propWidth1,
  propPadding,
  dateValuesDebugCommit,
  dateIconDebugCommit,
}) => {
  const bottomContainerStyle = useMemo(() => {
    return {
      width: propWidth,
      minWidth: propMinWidth,
    };
  }, [propWidth, propMinWidth]);

  const bottomContentStyle = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
      width: propWidth1,
      padding: propPadding,
    };
  }, [propAlignSelf, propWidth1, propPadding]);

  const dateValuesStyle = useMemo(() => {
    return {
      debugCommit: dateValuesDebugCommit,
    };
  }, [dateValuesDebugCommit]);

  const dateIconStyle = useMemo(() => {
    return {
      debugCommit: dateIconDebugCommit,
    };
  }, [dateIconDebugCommit]);

  return (
    <div
      className={`bottom-container ${className}`}
      style={bottomContainerStyle}
    >
      <div className="bottom-content" style={bottomContentStyle}>
        <img
          className="osfp-mak-s-2-icon2"
          loading="lazy"
          alt=""
          src="/osfpmaks-2@2x.png"
        />
        <div className="date-container">
          <div className="date-values-parent">
            <div className="date-values" style={dateValuesStyle}>
              <div className="date-shape" />
              <b className="saturday3">Saturday</b>
              <div className="apr-8-wrapper">
                <div className="apr-82">Apr 8</div>
              </div>
            </div>
            <div className="date-icon-wrapper">
              <img
                className="date-icon"
                loading="lazy"
                alt=""
                src="/vector-1.svg"
                style={dateIconStyle}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

BottomContainer.propTypes = {
  className: PropTypes.string,

  /** Style props */
  propWidth: PropTypes.any,
  propMinWidth: PropTypes.any,
  propAlignSelf: PropTypes.any,
  propWidth1: PropTypes.any,
  propPadding: PropTypes.any,
  dateValuesDebugCommit: PropTypes.any,
  dateIconDebugCommit: PropTypes.any,
};

export default BottomContainer;
