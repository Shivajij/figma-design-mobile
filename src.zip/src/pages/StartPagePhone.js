import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import FirstRow from "../components/FirstRow";
import SaturdayContainer from "../components/SaturdayContainer";
import LiveGames from "../components/LiveGames";
import "./StartPagePhone.css";

const StartPagePhone = () => {
  const navigate = useNavigate();

  const onGroupSwitchClick = useCallback(() => {
    navigate("/start-page-phone-menu");
  }, [navigate]);

  return (
    <div className="start-page-phone">
      <img
        className="timebattery-icon"
        loading="lazy"
        alt=""
        src="/timebattery.svg"
      />
      <img className="header-icon" loading="lazy" alt="" src="/header@2x.png" />
      <header className="rectangle-parent">
        <div className="frame-child" />
        <div className="rectangle-group" onClick={onGroupSwitchClick}>
          <div className="frame-item" />
          <div className="frame-inner" />
          <div className="rectangle-div" />
        </div>
      </header>
      <main className="main-content">
        <section className="left-column">
          <FirstRow />
          <SaturdayContainer />
        </section>
        <section className="live-games-parent">
          <LiveGames />
          <div className="content-scroller">
            <div className="scroller">
              <div className="scroller-child" />
              <div className="scroller-background" />
            </div>
          </div>
        </section>
      </main>
      <img className="footer-icon" alt="" src="/footer@2x.png" />
    </div>
  );
};

export default StartPagePhone;
