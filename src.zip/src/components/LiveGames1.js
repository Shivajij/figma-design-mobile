import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import "./LiveGames1.css";

const LiveGames1 = ({ className = "" }) => {
  const navigate = useNavigate();

  const onLiveGamesContainerClick = useCallback(() => {
    navigate("/ncaa-basketball-match-game-statistics");
  }, [navigate]);

  return (
    <div
      className={`live-games7 ${className}`}
      onClick={onLiveGamesContainerClick}
    >
      <div className="live-games-item" />
      <div className="live-games8">
        <div className="basketball-parent">
          <div className="header4" />
          <div className="basketball-header">
            <img
              className="basketball-2-icon2"
              loading="lazy"
              alt=""
              src="/basketball-2.svg"
            />
          </div>
          <b className="ncaa-basketball2">19:30 NCAA Basketball</b>
        </div>
        <div className="league-grid">
          <div className="live-game-item">
            <div className="game-info1">
              <div className="teams-container">
                <div className="home-team">
                  <div className="home-team-score">
                    <div className="home-team-live">
                      <div className="live13" />
                    </div>
                    <img
                      className="nfl-icon1"
                      loading="lazy"
                      alt=""
                      src="/nfl.svg"
                    />
                  </div>
                </div>
                <div className="away-team">
                  <div className="away-team-score">
                    <div className="live14" />
                  </div>
                  <img className="nba-icon3" alt="" src="/nba.svg" />
                </div>
                <div className="thumbnail-container">
                  <div className="thumbnail-live">
                    <img
                      className="image-28-icon6"
                      loading="lazy"
                      alt=""
                      src="/image-28@2x.png"
                    />
                    <div className="live15" />
                  </div>
                </div>
              </div>
              <div className="team-names">
                <div className="home-team-name">
                  <div className="townsom1">Townsom</div>
                  <div className="away-team-parent">
                    <div className="away-team-city">
                      <div className="philadelphia-76ers2">
                        <p className="philadelphia3">{`Philadelphia `}</p>
                        <p className="ers2">76ers</p>
                      </div>
                    </div>
                    <div className="pittsburgh-steelmen2">
                      <p className="pittsburgh1">Pittsburgh</p>
                      <p className="steelmen1">Steelmen</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="scores-grid">
              <div className="score-item">
                <div className="home-score">
                  <div className="home-score-details">
                    <b className="h4">45’ 1 H</b>
                    <b className="home-score-spacer">0 - 1</b>
                    <img className="ciltv-icon5" alt="" src="/ciltv.svg" />
                  </div>
                </div>
                <div className="away-score">
                  <div className="away-score-details">
                    <b className="away-score-spacer">0 - 1</b>
                    <div className="away-initial-parent">
                      <b className="h5">45’ 1 H</b>
                    </div>
                  </div>
                </div>
                <div className="live-score">
                  <b className="live-score-spacer">0 - 2</b>
                  <div className="live-initial-parent">
                    <b className="h6">45’ 1 H</b>
                  </div>
                </div>
              </div>
            </div>
            <div className="celtics-container">
              <div className="celtics-game">
                <div className="celtics-info">
                  <div className="celtics-details">
                    <div className="boston-celtic5">Boston Celtic</div>
                    <div className="opponent-team">
                      <div className="charlotte-hornets1">
                        <p className="charlotte1">Charlotte</p>
                        <p className="hornets1">Hornets</p>
                      </div>
                    </div>
                    <div className="boston-celtic6">Boston Celtic</div>
                  </div>
                </div>
                <div className="league-icons">
                  <div className="home-league">
                    <div className="home-league-details">
                      <img className="nba-icon4" alt="" src="/nba-1.svg" />
                      <div className="vector-wrapper">
                        <img
                          className="vector-icon10"
                          alt=""
                          src="/vector-2.svg"
                        />
                      </div>
                    </div>
                    <div className="away-league">
                      <div className="away-league-details">
                        <img
                          className="nba-icon5"
                          loading="lazy"
                          alt=""
                          src="/nba-2.svg"
                        />
                        <div className="vector-frame">
                          <img
                            className="vector-icon11"
                            alt=""
                            src="/vector-3.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="game-image-container">
                    <input className="image-29" type="checkbox" />
                    <img className="vector-icon12" alt="" src="/vector-4.svg" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="second-game">
        <img
          className="image-29-icon6"
          loading="lazy"
          alt=""
          src="/image-29-4@2x.png"
        />
        <img
          className="vector-icon13"
          loading="lazy"
          alt=""
          src="/vector-5.svg"
        />
      </div>
      <div className="north-american-parent">
        <div className="header5" />
        <div className="north-american-header">
          <img className="basketball-2-icon3" alt="" src="/basketball-2.svg" />
        </div>
        <b className="north-american-basketball1">
          20:00 North American Basketball League
        </b>
      </div>
      <div className="league-images">
        <div className="image-grid">
          <div className="first-image-container">
            <img className="image-29-icon7" alt="" src="/image-29-1@2x.png" />
            <img className="vector-icon14" alt="" src="/vector-5.svg" />
          </div>
          <div className="image-container">
            <img
              className="image-29-icon8"
              loading="lazy"
              alt=""
              src="/image-29-2@2x.png"
            />
            <img className="image-container-icon" alt="" src="/vector-5.svg" />
          </div>
          <div className="image-container1">
            <img className="image-29-icon9" alt="" src="/image-29-3@2x.png" />
            <img className="image-container-icon1" alt="" src="/vector-5.svg" />
          </div>
          <div className="live-games-grid">
            <div className="live-game-row">
              <div className="live-game-item1">
                <div className="image-live-container">
                  <img
                    className="image-28-icon7"
                    alt=""
                    src="/image-28-1@2x.png"
                  />
                  <div className="live16" />
                </div>
                <div className="image-live-container1">
                  <img
                    className="image-28-icon8"
                    loading="lazy"
                    alt=""
                    src="/image-28-2@2x.png"
                  />
                  <div className="live17" />
                </div>
                <div className="image-live-container2">
                  <img
                    className="image-28-icon9"
                    loading="lazy"
                    alt=""
                    src="/image-28-3@2x.png"
                  />
                  <div className="live18" />
                </div>
                <div className="image-live-container3">
                  <img
                    className="image-28-icon10"
                    loading="lazy"
                    alt=""
                    src="/image-28-4@2x.png"
                  />
                  <div className="live19" />
                </div>
              </div>
            </div>
            <div className="team-score-container1">
              <div className="team-names-container">
                <div className="team-names-row1">
                  <b className="h7">45’ 1 H</b>
                  <div className="generals-celtic-container">
                    <div className="generals-container">
                      <div className="boston-generals1">Boston Generals</div>
                    </div>
                    <b className="team-name-separator">0 - 1</b>
                    <div className="celtic-container">
                      <div className="boston-celtic7">Boston Celtic</div>
                    </div>
                  </div>
                  <img className="ciltv-icon6" alt="" src="/ciltv.svg" />
                </div>
              </div>
              <div className="wolves-sixers-container">
                <div className="wolves-sixers-row">
                  <div className="denver-wolves1">Denver Wolves</div>
                  <div className="philadelphia-76ers3">
                    <p className="philadelphia4">{`Philadelphia `}</p>
                    <p className="ers3">76ers</p>
                  </div>
                </div>
                <div className="mavericks-celtic-container">
                  <div className="mavericks-celtic-row">
                    <div className="mavericks-celtic-items">
                      <b className="team-name-spacers">0 - 1</b>
                      <div className="mavericks-celtic-names">
                        <div className="mavericks1">Mavericks</div>
                      </div>
                    </div>
                    <div className="mavericks-celtic-items1">
                      <b className="b18">0 - 1</b>
                      <div className="boston-celtic-wrapper">
                        <div className="boston-celtic8">Boston Celtic</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bears-celtic-container">
                <div className="bears-container">
                  <div className="newark-bears1">Newark Bears</div>
                </div>
                <div className="bears-celtic-items">
                  <b className="bears-celtic-names">0 - 1</b>
                </div>
                <div className="bears-celtic-items1">
                  <div className="boston-celtic9">Boston Celtic</div>
                </div>
              </div>
            </div>
            <div className="image-container2">
              <div className="image-row">
                <img
                  className="image-29-icon10"
                  alt=""
                  src="/image-29-5@2x.png"
                />
                <img className="vector-icon15" alt="" src="/vector.svg" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="steelmen-container">
        <div className="steelmen-row">
          <div className="steelmen-item">
            <div className="live-game-item2">
              <img
                className="image-28-icon11"
                loading="lazy"
                alt=""
                src="/image-28-5@2x.png"
              />
              <div className="live20" />
            </div>
            <div className="team-name-container">
              <div className="pittsburgh-steelmen3">Pittsburgh Steelmen</div>
            </div>
            <div className="team-separator">
              <b className="separator-content">0 - 1</b>
            </div>
          </div>
          <div className="lumberjacks-container">
            <div className="portland-lumberjacks1">
              <p className="portland1">Portland</p>
              <p className="lumberjacks1">Lumberjacks</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

LiveGames1.propTypes = {
  className: PropTypes.string,
};

export default LiveGames1;
