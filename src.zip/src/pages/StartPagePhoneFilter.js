import { useCallback } from "react";
import LiveGames1 from "../components/LiveGames1";
import { useNavigate } from "react-router-dom";
import BottomContainer from "../components/BottomContainer";
import "./StartPagePhoneFilter.css";

const StartPagePhoneFilter = () => {
  const navigate = useNavigate();

  const onXIconClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className="start-page-phone-filter">
      <div className="tomorrow">
        <div className="tomorrow-child" />
        <div className="apr-1">Apr 1</div>
        <b className="tomorrow1">Tomorrow</b>
      </div>
      <div className="thursday">
        <div className="thursday-child" />
        <div className="apr-2">Apr 2</div>
        <b className="thursday1">Thursday</b>
      </div>
      <main className="main">
        <section className="sport-info">
          <div className="today">
            <div className="today-rect" />
            <div className="today-parent">
              <b className="today1">Today</b>
            </div>
            <div className="mar-30">Mar 30</div>
          </div>
          <div className="friday-parent">
            <div className="friday-rect" />
            <b className="friday">Friday</b>
            <div className="april-parent">
              <div className="apr-7">Apr 7</div>
            </div>
          </div>
          <img className="osfp-mak-s-1-icon" alt="" src="/osfpmaks-1@2x.png" />
          <img
            className="bay-laz-s-2-icon"
            loading="lazy"
            alt=""
            src="/baylazs-2@2x.png"
          />
          <div className="header-container">
            <img className="timebattery-icon1" alt="" src="/timebattery1.svg" />
            <img className="header-icon1" alt="" src="/header@2x.png" />
          </div>
          <LiveGames1 />
          <div className="live" />
          <a className="live-games">Live Games</a>
          <img
            className="vector-icon"
            loading="lazy"
            alt=""
            src="/vector.svg"
          />
          <div className="search-filter-container">
            <div className="search-filter-container-child" />
            <div className="search-filter-row">
              <img
                className="x-icon"
                loading="lazy"
                alt=""
                src="/x.svg"
                onClick={onXIconClick}
              />
              <div className="search">
                <div className="search-child" />
                <div className="search-bar">
                  <img className="search-icon" alt="" src="/search.svg" />
                </div>
                <div className="search-sport-country">
                  Search sport, country, league
                </div>
              </div>
              <div className="filter-chips-container">
                <div className="basketball-america-container">
                  <div className="basketball-x">
                    <div className="basketball-x-child" />
                    <div className="basketball">Basketball</div>
                    <div className="close-icon-containers">
                      <a className="x">x</a>
                    </div>
                  </div>
                  <div className="america-x">
                    <div className="america-x-child" />
                    <div className="america">America</div>
                    <div className="x-wrapper">
                      <a className="x1">x</a>
                    </div>
                  </div>
                </div>
                <div className="usa-x">
                  <div className="usa-x-child" />
                  <h3 className="usa">USA</h3>
                  <div className="usa-close-container">
                    <h2 className="x2">x</h2>
                  </div>
                </div>
              </div>
              <div className="continent-filter-container">
                <div className="continent-country-dropdown">
                  <div className="filter-by-continent-label-cont">
                    <h3 className="filter-by-continent">{`Filter By Continent or Country `}</h3>
                  </div>
                  <div className="continent-country-items">
                    <div className="continent-country-options">
                      <div className="option-placeholders" />
                      <div className="continent-country-labels">
                        <img
                          className="americas-1-icon"
                          loading="lazy"
                          alt=""
                          src="/americas-1@2x.png"
                        />
                        <div className="subcontinent-labels">
                          <b className="america1">America</b>
                        </div>
                      </div>
                      <div className="country-labels">
                        <b className="country-names">15</b>
                      </div>
                    </div>
                  </div>
                  <div className="continent-country-items1">
                    <div className="argentina">
                      <div className="argentina-child" />
                      <div className="image-21-wrapper">
                        <img
                          className="image-21-icon"
                          loading="lazy"
                          alt=""
                          src="/image-21@2x.png"
                        />
                      </div>
                      <a className="argentina1">Argentina</a>
                    </div>
                  </div>
                  <div className="continent-country-items2">
                    <div className="bolivia">
                      <div className="bolivia-child" />
                      <div className="image-22-wrapper">
                        <img
                          className="image-22-icon"
                          alt=""
                          src="/image-22@2x.png"
                        />
                      </div>
                      <h3 className="bolivia1">Bolivia</h3>
                    </div>
                  </div>
                  <div className="continent-country-items3">
                    <div className="colombia">
                      <div className="colombia-child" />
                      <div className="image-23-wrapper">
                        <img
                          className="image-23-icon"
                          alt=""
                          src="/image-23@2x.png"
                        />
                      </div>
                      <h3 className="colombia1">Colombia</h3>
                    </div>
                  </div>
                  <div className="continent-country-items4">
                    <div className="mexico">
                      <div className="mexico-child" />
                      <div className="image-21-container">
                        <img
                          className="image-21-icon1"
                          alt=""
                          src="/image-21-1@2x.png"
                        />
                      </div>
                      <a className="mexico1">Mexico</a>
                    </div>
                  </div>
                  <div className="continent-country-items5">
                    <div className="mexico2">
                      <div className="mexico-item" />
                      <div className="image-22-container">
                        <img
                          className="image-22-icon1"
                          alt=""
                          src="/image-22-1@2x.png"
                        />
                      </div>
                      <h3 className="usa1">USA</h3>
                    </div>
                  </div>
                  <div className="continent-country-items6">
                    <div className="europe">
                      <div className="europe-child" />
                      <div className="europe-1-parent">
                        <img
                          className="europe-1-icon"
                          loading="lazy"
                          alt=""
                          src="/europe-1@2x.png"
                        />
                        <div className="europe-wrapper">
                          <b className="europe1">Europe</b>
                        </div>
                      </div>
                      <div className="wrapper">
                        <b className="b">182</b>
                      </div>
                    </div>
                  </div>
                  <div className="continent-country-items7">
                    <div className="africa">
                      <div className="africa-child" />
                      <div className="africa-1-parent">
                        <img
                          className="africa-1-icon"
                          loading="lazy"
                          alt=""
                          src="/africa-1@2x.png"
                        />
                        <div className="africa-wrapper">
                          <b className="africa1">Africa</b>
                        </div>
                      </div>
                      <div className="container">
                        <b className="b1">10</b>
                      </div>
                    </div>
                  </div>
                  <div className="continent-country-items8">
                    <div className="oceania">
                      <div className="oceania-child" />
                      <img
                        className="oceania-1-icon"
                        loading="lazy"
                        alt=""
                        src="/oceania-1@2x.png"
                      />
                      <div className="separator-container">
                        <b className="oceania1">Oceania</b>
                      </div>
                      <div className="separator-container1">
                        <b className="separator">2</b>
                      </div>
                    </div>
                  </div>
                  <div className="continent-country-items9">
                    <div className="international">
                      <div className="international-child" />
                      <img
                        className="international-1-icon"
                        loading="lazy"
                        alt=""
                        src="/international-1@2x.png"
                      />
                      <div className="international-wrapper">
                        <b className="international1">International</b>
                      </div>
                      <div className="frame">
                        <b className="b2">3</b>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="sports-filter-container">
              <div className="sports-dropdown">
                <div className="basket">
                  <div className="sports-items" />
                  <div className="sports-icon-containers">
                    <img
                      className="basketball-1-icon"
                      loading="lazy"
                      alt=""
                      src="/basketball-1.svg"
                    />
                    <div className="basket-wrapper">
                      <b className="basket1">Basket</b>
                    </div>
                  </div>
                  <div className="frame-div">
                    <b className="b3">15</b>
                  </div>
                </div>
                <div className="sports-options">
                  <div className="ncaa-basket">
                    <div className="ncaa-basket-child" />
                    <div className="sports-image-containers">
                      <img
                        className="image-19-icon"
                        loading="lazy"
                        alt=""
                        src="/image-19@2x.png"
                      />
                    </div>
                    <div className="sports-label-containers">
                      <div className="ncaa-basketball">NCAA Basketball</div>
                    </div>
                    <div className="sports-separator-containers">
                      <b className="sports-separators">10</b>
                    </div>
                  </div>
                </div>
                <div className="sports-options1">
                  <div className="north-america">
                    <div className="north-america-child" />
                    <div className="image-20-wrapper">
                      <img
                        className="image-20-icon"
                        loading="lazy"
                        alt=""
                        src="/image-20@2x.png"
                      />
                    </div>
                    <div className="north-american-basketball-leag-wrapper">
                      <div className="north-american-basketball-container">
                        <p className="north-american">{`North American `}</p>
                        <p className="basketball-league">Basketball League</p>
                      </div>
                    </div>
                    <div className="wrapper1">
                      <b className="b4">5</b>
                    </div>
                  </div>
                </div>
                <div className="hockey">
                  <div className="hockey-child" />
                  <div className="hockey-1-parent">
                    <img
                      className="hockey-1-icon"
                      loading="lazy"
                      alt=""
                      src="/hockey-1.svg"
                    />
                    <div className="hockey-wrapper">
                      <b className="hockey1">Hockey</b>
                    </div>
                  </div>
                  <div className="wrapper2">
                    <b className="b5">20</b>
                  </div>
                </div>
                <div className="american-football">
                  <div className="american-football-child" />
                  <div className="american-football-1-parent">
                    <img
                      className="american-football-1-icon"
                      loading="lazy"
                      alt=""
                      src="/americanfootball-1.svg"
                    />
                    <div className="football-wrapper">
                      <b className="football">Football</b>
                    </div>
                  </div>
                  <div className="wrapper3">
                    <b className="b6">57</b>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="soccer">
            <div className="soccer-rect" />
            <img
              className="vector-icon1"
              loading="lazy"
              alt=""
              src="/vector-9.svg"
            />
            <div className="soccer-parent">
              <b className="soccer1">Soccer</b>
            </div>
          </div>
          <div className="soccer2">
            <div className="soccer-child" />
            <b className="tennis">Tennis</b>
            <div className="football-1" />
          </div>
          <h3 className="filter-by-sports">Filter By Sports</h3>
          <b className="empty-label">5</b>
          <img className="footer-icon1" alt="" src="/footer@2x.png" />
        </section>
      </main>
      <div className="background-shape" />
      <div className="start-page-phone-filter-child" />
      <div className="start-page-phone-filter-item" />
      <div className="start-page-phone-filter-inner" />
      <div className="filter-by-sports1">Filter by sports or area</div>
      <div className="scroller1">
        <div className="scroller-item" />
        <div className="scroller-inner" />
      </div>
      <div className="find-your-tournament">Find your tournament</div>
      <BottomContainer />
    </div>
  );
};

export default StartPagePhoneFilter;
