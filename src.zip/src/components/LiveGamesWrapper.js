import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import "./LiveGamesWrapper.css";

const LiveGamesWrapper = ({ className = "" }) => {
  const navigate = useNavigate();

  const onLiveGamesContainerClick = useCallback(() => {
    navigate("/ncaa-basketball-match-game-statistics");
  }, [navigate]);

  return (
    <section className={`live-games-wrapper1 ${className}`}>
      <div className="live-games10" onClick={onLiveGamesContainerClick}>
        <div className="live-games-child1" />
        <div className="games-container1">
          <div className="basketball-games">
            <div className="n-c-a-a-basketball">
              <div className="header8" />
              <div className="basketball-2-wrapper">
                <img
                  className="basketball-2-icon6"
                  loading="lazy"
                  alt=""
                  src="/basketball-2.svg"
                />
              </div>
              <b className="ncaa-basketball4">19:30 NCAA Basketball</b>
            </div>
            <div className="league-games">
              <div className="n-f-l-option">
                <div className="live-n-f-l">
                  <div className="n-f-l-image">
                    <div className="n-f-l-details">
                      <div className="n-f-l-footer">
                        <div className="n-f-live">
                          <div className="live29" />
                        </div>
                        <img
                          className="nfl-icon3"
                          loading="lazy"
                          alt=""
                          src="/nfl.svg"
                        />
                      </div>
                    </div>
                    <div className="n-b-a-option">
                      <div className="live-n-b-a">
                        <div className="live30" />
                      </div>
                      <img
                        className="nba-icon9"
                        loading="lazy"
                        alt=""
                        src="/nba.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className="n-b-a-games">
                  <div className="townsom-game">
                    <div className="townsom-details">
                      <div className="townsom3">Townsom</div>
                    </div>
                    <div className="townsom-footer">
                      <div className="townsom-ciltv">
                        <img
                          className="ciltv-icon9"
                          loading="lazy"
                          alt=""
                          src="/ciltv.svg"
                        />
                      </div>
                      <div className="townsom-space">
                        <b className="b20">0 - 1</b>
                      </div>
                      <div className="townsom-h">
                        <b className="h12">45’ 1 H</b>
                      </div>
                    </div>
                    <div className="celtics-game1">
                      <div className="celtics-details1">
                        <div className="boston-celtic-container">
                          <div className="boston-celtic15">Boston Celtic</div>
                        </div>
                        <div className="celtics-footer">
                          <img
                            className="nba-icon10"
                            loading="lazy"
                            alt=""
                            src="/nba-1.svg"
                          />
                          <div className="vector-wrapper3">
                            <img
                              className="vector-icon24"
                              loading="lazy"
                              alt=""
                              src="/vector-2.svg"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="sixers-game">
                    <div className="sixers-details">
                      <div className="philadelphia-76ers-frame">
                        <div className="philadelphia-76ers6">
                          <p className="philadelphia7">{`Philadelphia `}</p>
                          <p className="ers6">76ers</p>
                        </div>
                      </div>
                      <div className="sixers-footer">
                        <div className="sixers-space">
                          <b className="b21">0 - 1</b>
                          <div className="sixers-h">
                            <b className="h13">45’ 1 H</b>
                          </div>
                        </div>
                      </div>
                      <div className="hornets-game">
                        <div className="hornets-details">
                          <div className="charlotte-hornets3">
                            <p className="charlotte3">Charlotte</p>
                            <p className="hornets3">Hornets</p>
                          </div>
                        </div>
                        <img
                          className="nba-icon11"
                          loading="lazy"
                          alt=""
                          src="/nba-2.svg"
                        />
                        <div className="vector-wrapper4">
                          <img
                            className="vector-icon25"
                            loading="lazy"
                            alt=""
                            src="/vector-3.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="steelers-game">
            <div className="steelers-details">
              <div className="steelers-header">
                <div className="steelers-image">
                  <img
                    className="image-28-icon18"
                    loading="lazy"
                    alt=""
                    src="/image-28@2x.png"
                  />
                  <div className="live31" />
                </div>
                <div className="steelers-name">
                  <div className="pittsburgh-steelmen6">
                    <p className="pittsburgh3">Pittsburgh</p>
                    <p className="steelmen3">Steelmen</p>
                  </div>
                </div>
              </div>
              <div className="steelers-footer">
                <div className="steelers-space">
                  <b className="b22">0 - 2</b>
                  <div className="steelers-h">
                    <b className="h14">45’ 1 H</b>
                  </div>
                </div>
              </div>
              <div className="celtics-details-two">
                <div className="celtics-header-two">
                  <div className="celtics-image">
                    <div className="boston-celtic16">Boston Celtic</div>
                  </div>
                  <div className="image-29-parent">
                    <img
                      className="image-29-icon17"
                      loading="lazy"
                      alt=""
                      src="/image-29@2x.png"
                    />
                    <img
                      className="north-american-league"
                      alt=""
                      src="/vector-4.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="n-a-l-basketball">
            <div className="header9" />
            <div className="basketball-2-container">
              <img
                className="basketball-2-icon7"
                alt=""
                src="/basketball-2.svg"
              />
            </div>
            <b className="north-american-basketball3">
              20:00 North American Basketball League
            </b>
          </div>
        </div>
        <div className="image-gallery1">
          <div className="gallery-container1">
            <div className="gallery-item-two">
              <img
                className="image-29-icon18"
                loading="lazy"
                alt=""
                src="/image-29-1@2x.png"
              />
              <img className="vector-icon26" alt="" src="/vector-5.svg" />
            </div>
            <div className="gallery-item-one">
              <img
                className="image-29-icon19"
                loading="lazy"
                alt=""
                src="/image-29-2@2x.png"
              />
              <img className="vector-icon27" alt="" src="/vector-5.svg" />
            </div>
            <div className="gallery-item-three">
              <img
                className="image-29-icon20"
                loading="lazy"
                alt=""
                src="/image-29-3@2x.png"
              />
              <img className="vector-icon28" alt="" src="/vector-5.svg" />
            </div>
            <div className="gallery-item-one1">
              <img
                className="image-29-icon21"
                loading="lazy"
                alt=""
                src="/image-29-4@2x.png"
              />
              <img
                className="vector-icon29"
                loading="lazy"
                alt=""
                src="/vector-5.svg"
              />
            </div>
            <div className="game-info-container-parent">
              <div className="game-info-container">
                <div className="game-card">
                  <div className="game-content1">
                    <div className="live-game-container1">
                      <div className="game-time-info">
                        <img
                          className="image-28-icon19"
                          loading="lazy"
                          alt=""
                          src="/image-28-1@2x.png"
                        />
                        <div className="live32" />
                      </div>
                      <div className="team-name-container3">
                        <div className="boston-generals3">Boston Generals</div>
                      </div>
                    </div>
                  </div>
                  <div className="game-details3">
                    <div className="city-name-team-container">
                      <b className="b23">0 - 1</b>
                      <div className="opponent-name">
                        <div className="boston-celtic17">Boston Celtic</div>
                      </div>
                    </div>
                    <img className="ciltv-icon10" alt="" src="/ciltv.svg" />
                    <b className="h15">45’ 1 H</b>
                  </div>
                </div>
                <div className="game-team-container">
                  <div className="team-info-container">
                    <div className="team-logo-container">
                      <div className="team-logos">
                        <img
                          className="image-28-icon20"
                          loading="lazy"
                          alt=""
                          src="/image-28-2@2x.png"
                        />
                        <div className="live33" />
                      </div>
                      <div className="live-indicators">
                        <div className="denver-wolves3">Denver Wolves</div>
                      </div>
                    </div>
                    <div className="team-names2">
                      <b className="team-city-names">0 - 1</b>
                    </div>
                  </div>
                  <div className="opponent-team-info">
                    <div className="mavericks3">Mavericks</div>
                  </div>
                </div>
                <div className="game-team-container1">
                  <div className="frame-parent5">
                    <div className="image-28-parent3">
                      <img
                        className="image-28-icon21"
                        loading="lazy"
                        alt=""
                        src="/image-28-3@2x.png"
                      />
                      <div className="live34" />
                    </div>
                    <div className="philadelphia-76ers-wrapper1">
                      <div className="philadelphia-76ers7">
                        <p className="philadelphia8">{`Philadelphia `}</p>
                        <p className="ers7">76ers</p>
                      </div>
                    </div>
                  </div>
                  <div className="game-team-container-inner">
                    <div className="opponent-city-names-parent">
                      <b className="opponent-city-names">0 - 1</b>
                      <div className="boston-celtic18">Boston Celtic</div>
                    </div>
                  </div>
                </div>
                <div className="game-team-container2">
                  <div className="frame-parent6">
                    <div className="image-28-parent4">
                      <img
                        className="image-28-icon22"
                        loading="lazy"
                        alt=""
                        src="/image-28-4@2x.png"
                      />
                      <div className="live35" />
                    </div>
                    <div className="newark-bears-frame">
                      <div className="newark-bears3">Newark Bears</div>
                    </div>
                  </div>
                  <div className="game-team-container-child">
                    <div className="group">
                      <b className="b24">0 - 1</b>
                      <div className="boston-celtic19">Boston Celtic</div>
                    </div>
                  </div>
                </div>
                <div className="game-team-container3">
                  <div className="frame-parent7">
                    <div className="image-28-parent5">
                      <img
                        className="image-28-icon23"
                        loading="lazy"
                        alt=""
                        src="/image-28-5@2x.png"
                      />
                      <div className="live36" />
                    </div>
                    <div className="pittsburgh-steelmen-container">
                      <div className="pittsburgh-steelmen7">
                        Pittsburgh Steelmen
                      </div>
                    </div>
                    <div className="city-name-container">
                      <b className="b25">0 - 1</b>
                    </div>
                  </div>
                  <div className="portland-lumberjacks-container">
                    <div className="portland-lumberjacks3">
                      <p className="portland3">Portland</p>
                      <p className="lumberjacks3">Lumberjacks</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="frame-wrapper">
                <div className="image-29-group">
                  <img
                    className="image-29-icon22"
                    loading="lazy"
                    alt=""
                    src="/image-29-5@2x.png"
                  />
                  <img className="vector-icon30" alt="" src="/vector.svg" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <img className="footer-icon4" alt="" src="/footer@2x.png" />
      </div>
    </section>
  );
};

LiveGamesWrapper.propTypes = {
  className: PropTypes.string,
};

export default LiveGamesWrapper;
