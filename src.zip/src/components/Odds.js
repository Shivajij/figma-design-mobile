import "./Odds.css";
import PropTypes from 'prop-types';
const Odds = ({ className = "" }) => {
  return (
    <div className={`odds ${className}`}>
      <div className="odds-elements">
        <div className="odds-elements-child" />
        <b className="odd-values">1,22</b>
      </div>
      <div className="odds-elements1">
        <div className="odds-elements-item" />
        <b className="b29">1,22</b>
      </div>
      <div className="odds-elements2">
        <div className="odds-elements-inner" />
        <b className="b30">2,60</b>
      </div>
      <div className="odds-elements3">
        <div className="odds-elements-child1" />
        <b className="b31">2,60</b>
      </div>
      <div className="odds-elements4">
        <div className="odds-elements-child2" />
        <b className="b32">3,80</b>
      </div>
      <div className="odds-elements5">
        <div className="odds-elements-child3" />
        <b className="b33">3,80</b>
      </div>
      <div className="odds-elements6">1</div>
      <div className="x3">X</div>
      <div className="odds-elements7">2</div>
    </div>
  );
};

Odds.propTypes = {
  className: PropTypes.string,
};

export default Odds;
