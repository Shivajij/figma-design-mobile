import "./LiveGames.css";
import PropTypes from 'prop-types';

const LiveGames = ({ className = "" }) => {
  return (
    <div className={`live-games6 ${className}`}>
      <div className="live-games-child" />
      <div className="games-list">
        <div className="league-header-parent">
          <div className="league-header">
            <div className="header2" />
            <div className="basketball-icon">
              <img
                className="basketball-2-icon"
                loading="lazy"
                alt=""
                src="/basketball-2.svg"
              />
            </div>
            <b className="ncaa-basketball1">19:30 NCAA Basketball</b>
          </div>
          <div className="game-rows">
            <div className="first-game-row">
              <div className="game-details">
                <div className="team-container">
                  <div className="team-one">
                    <div className="live-game">
                      <div className="live5" />
                    </div>
                    <img
                      className="nfl-icon"
                      loading="lazy"
                      alt=""
                      src="/nfl.svg"
                    />
                  </div>
                </div>
                <div className="team-two">
                  <div className="live-indicator-n-b-a">
                    <div className="live6" />
                  </div>
                  <img
                    className="nba-icon"
                    loading="lazy"
                    alt=""
                    src="/nba.svg"
                  />
                </div>
                <div className="team-three">
                  <div className="game-image">
                    <img
                      className="image-28-icon"
                      loading="lazy"
                      alt=""
                      src="/image-28@2x.png"
                    />
                    <div className="live7" />
                  </div>
                </div>
              </div>
              <div className="game-info">
                <div className="team-details">
                  <img
                    className="ciltv-icon3"
                    loading="lazy"
                    alt=""
                    src="/ciltv.svg"
                  />
                  <div className="scoreboard">
                    <div className="team-names-row">
                      <div className="townsom">Townsom</div>
                      <div className="team-location">
                        <div className="philadelphia">
                          <div className="philadelphia-76ers">
                            <p className="philadelphia1">{`Philadelphia `}</p>
                            <p className="ers">76ers</p>
                          </div>
                        </div>
                        <div className="pittsburgh-steelmen">
                          <p className="pittsburgh">Pittsburgh</p>
                          <p className="steelmen">Steelmen</p>
                        </div>
                      </div>
                    </div>
                    <div className="score-row-one">
                      <div className="first-score">
                        <div className="first-score-details">
                          <b className="first-score-dash">0 - 1</b>
                          <div className="first-score-h">
                            <b className="h">45’ 1 H</b>
                          </div>
                        </div>
                      </div>
                      <div className="second-score">
                        <div className="second-score-details">
                          <b className="second-score-dash">0 - 1</b>
                          <div className="second-score-h">
                            <b className="h1">45’ 1 H</b>
                          </div>
                        </div>
                      </div>
                      <div className="third-score">
                        <b className="third-score-dash">0 - 2</b>
                        <div className="third-score-h">
                          <b className="h2">45’ 1 H</b>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="second-game-row">
                <div className="game-details-two">
                  <div className="container1">
                    <div className="team-score-container">
                      <div className="team-container1">
                        <div className="boston-celtic">Boston Celtic</div>
                      </div>
                      <div className="league-info">
                        <img
                          className="nba-icon1"
                          loading="lazy"
                          alt=""
                          src="/nba-1.svg"
                        />
                        <div className="league-icon-container">
                          <img
                            className="league-icon"
                            loading="lazy"
                            alt=""
                            src="/vector-2.svg"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="opponent-container">
                      <div className="opponent-details">
                        <div className="opponent-name-container">
                          <div className="charlotte-hornets">
                            <p className="charlotte">Charlotte</p>
                            <p className="hornets">Hornets</p>
                          </div>
                        </div>
                        <img
                          className="nba-icon2"
                          loading="lazy"
                          alt=""
                          src="/nba-2.svg"
                        />
                        <div className="opponent-league-icon-container">
                          <img
                            className="opponent-league-icon"
                            loading="lazy"
                            alt=""
                            src="/vector-3.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="live-team-container">
                    <div className="live-team-details">
                      <div className="boston-celtic1">Boston Celtic</div>
                    </div>
                    <div className="team-status">
                      <img
                        className="image-29-icon"
                        loading="lazy"
                        alt=""
                        src="/image-29@2x.png"
                      />
                      <img
                        className="vector-icon7"
                        alt=""
                        src="/vector-4.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="basketball-league1">
          <div className="header3" />
          <div className="league-details">
            <img
              className="basketball-2-icon1"
              alt=""
              src="/basketball-2.svg"
            />
          </div>
          <b className="north-american-basketball">
            20:00 North American Basketball League
          </b>
        </div>
      </div>
      <div className="games-container">
        <div className="games-list1">
          <div className="live-game-container-parent">
            <div className="live-game-container">
              <div className="live-game-info">
                <div className="live-game-visuals">
                  <img
                    className="image-28-icon1"
                    loading="lazy"
                    alt=""
                    src="/image-28-1@2x.png"
                  />
                  <div className="live8" />
                </div>
              </div>
              <div className="competing-team">
                <div className="boston-generals">Boston Generals</div>
              </div>
              <div className="broadcaster-details">
                <div className="broadcaster-container">
                  <img className="ciltv-icon4" alt="" src="/ciltv.svg" />
                </div>
                <div className="home-indicator">
                  <b className="home-flag">0 - 1</b>
                </div>
                <div className="home-label">
                  <b className="h3">45’ 1 H</b>
                </div>
              </div>
            </div>
            <div className="game-trio">
              <div className="game-info-trio">
                <div className="live-game-details">
                  <img
                    className="image-28-icon2"
                    loading="lazy"
                    alt=""
                    src="/image-28-2@2x.png"
                  />
                  <div className="live9" />
                </div>
                <div className="game-name-trio">
                  <div className="denver-wolves">Denver Wolves</div>
                </div>
              </div>
              <div className="score-placeholder-trio">
                <b className="score-trio">0 - 1</b>
              </div>
            </div>
            <div className="game-trio1">
              <div className="frame-container">
                <div className="image-28-parent">
                  <img
                    className="image-28-icon3"
                    loading="lazy"
                    alt=""
                    src="/image-28-3@2x.png"
                  />
                  <div className="live10" />
                </div>
                <div className="philadelphia-76ers-wrapper">
                  <div className="philadelphia-76ers1">
                    <p className="philadelphia2">{`Philadelphia `}</p>
                    <p className="ers1">76ers</p>
                  </div>
                </div>
              </div>
              <div className="wrapper4">
                <b className="b16">0 - 1</b>
              </div>
            </div>
            <div className="game-trio2">
              <div className="frame-parent1">
                <div className="image-28-group">
                  <img
                    className="image-28-icon4"
                    loading="lazy"
                    alt=""
                    src="/image-28-4@2x.png"
                  />
                  <div className="live11" />
                </div>
                <div className="newark-bears-wrapper">
                  <div className="newark-bears">Newark Bears</div>
                </div>
              </div>
              <div className="wrapper5">
                <b className="b17">0 - 1</b>
              </div>
            </div>
            <div className="opponent-game">
              <div className="opponent-game-data">
                <img
                  className="image-28-icon5"
                  loading="lazy"
                  alt=""
                  src="/image-28-5@2x.png"
                />
                <div className="live12" />
              </div>
              <div className="opponent-game-team">
                <div className="pittsburgh-steelmen1">Pittsburgh Steelmen</div>
              </div>
              <div className="opponent-score-placeholder">
                <b className="opponent-score">0 - 1</b>
              </div>
            </div>
          </div>
          <div className="upcoming-games1">
            <div className="game-previews">
              <div className="game-preview-container">
                <img
                  className="image-29-icon1"
                  loading="lazy"
                  alt=""
                  src="/image-29-1@2x.png"
                />
                <img
                  className="game-indicator-icon"
                  alt=""
                  src="/vector-5.svg"
                />
              </div>
              <div className="team-images">
                <img
                  className="image-29-icon2"
                  loading="lazy"
                  alt=""
                  src="/image-29-2@2x.png"
                />
                <img
                  className="team-indicator-pair"
                  alt=""
                  src="/vector-5.svg"
                />
              </div>
              <div className="opponent-preview">
                <img
                  className="image-29-icon3"
                  loading="lazy"
                  alt=""
                  src="/image-29-3@2x.png"
                />
                <img
                  className="opponent-game-indicator"
                  alt=""
                  src="/vector-5.svg"
                />
              </div>
              <div className="team-images1">
                <img
                  className="image-29-icon4"
                  loading="lazy"
                  alt=""
                  src="/image-29-4@2x.png"
                />
                <img
                  className="vector-icon8"
                  loading="lazy"
                  alt=""
                  src="/vector-5.svg"
                />
              </div>
              <div className="team-matchup">
                <div className="team-matchup-details">
                  <div className="matchup-teams">
                    <div className="first-team">
                      <div className="boston-celtic2">Boston Celtic</div>
                    </div>
                    <div className="mavericks">Mavericks</div>
                    <div className="boston-celtic3">Boston Celtic</div>
                    <div className="second-team-details">
                      <div className="boston-celtic4">Boston Celtic</div>
                      <div className="portland-lumberjacks">
                        <p className="portland">Portland</p>
                        <p className="lumberjacks">Lumberjacks</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="matchup-info">
                  <img
                    className="image-29-icon5"
                    loading="lazy"
                    alt=""
                    src="/image-29-5@2x.png"
                  />
                  <img className="vector-icon9" alt="" src="/vector.svg" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

LiveGames.propTypes = {
  className: PropTypes.string,
};

export default LiveGames;
