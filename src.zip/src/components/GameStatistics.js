import "./GameStatistics.css";
import PropTypes from 'prop-types';

const GameStatistics = ({ className = "" }) => {
  return (
    <div className={`game-statistics-3 ${className}`}>
      <div className="progressbar">
        <div className="game-statistics1">Game Statistics</div>
        <div className="progress-bar-background" />
        <img
          className="progress-bar-elements"
          loading="lazy"
          alt=""
          src="/vector-92.svg"
        />
        <img
          className="progress-bar-elements1"
          loading="lazy"
          alt=""
          src="/vector-10.svg"
        />
        <div className="apr-15">Apr 1</div>
        <div className="nov-12">Nov 12</div>
      </div>
      <div className="pokal-left">
        <img className="pokal-1-icon" alt="" src="/pokal-1.svg" />
        <img
          className="pokal-2-icon"
          loading="lazy"
          alt=""
          src="/pokal-2.svg"
        />
        <img
          className="pokal-left-child"
          loading="lazy"
          alt=""
          src="/line-7.svg"
        />
        <div className="left-team-ranking">7</div>
        <div className="rank">Rank</div>
      </div>
      <div className="pokal-right">
        <img className="pokal-1-icon1" alt="" src="/pokal-1-1.svg" />
        <img
          className="pokal-2-icon1"
          loading="lazy"
          alt=""
          src="/pokal-2-1.svg"
        />
        <img
          className="pokal-right-child"
          loading="lazy"
          alt=""
          src="/line-7-1.svg"
        />
        <div className="rank1">Rank</div>
        <div className="right-team-ranking">10</div>
      </div>
      <div className="last-five">
        <img
          className="last-five-elements"
          alt=""
          src="/last-five-elements.svg"
        />
        <img
          className="last-five-elements1"
          alt=""
          src="/last-five-elements1.svg"
        />
        <div className="last-five1">Last Five</div>
        <div className="last-five2">Last Five</div>
        <img
          className="last-five-elements2"
          loading="lazy"
          alt=""
          src="/group-27.svg"
        />
        <img
          className="right-team-last-5"
          loading="lazy"
          alt=""
          src="/right-team-last-5.svg"
        />
      </div>
      <div className="odds1">
        <div className="odds-elements8" />
        <div className="odds-elements9" />
        <b className="x4">X</b>
        <div className="odds-elements10" />
        <div className="odds-elements11" />
        <b className="odds-value">1</b>
        <div className="odds-elements12">4 - 57.1%</div>
        <div className="odds-elements13">3 - 42.9%</div>
      </div>
    </div>
  );
};

GameStatistics.propTypes = {
  className: PropTypes.string,
};

export default GameStatistics;
